﻿namespace Algorithm
{
    public enum FT
    {
        One,
        Two
    }
}