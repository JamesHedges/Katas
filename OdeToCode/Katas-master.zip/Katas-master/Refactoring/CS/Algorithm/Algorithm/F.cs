﻿using System;

namespace Algorithm
{
    public class F
    {
        public Thing P1 { get; set; }
        public Thing P2 { get; set; }
        public TimeSpan D { get; set; }
    }
}