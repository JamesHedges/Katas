﻿using System;

namespace Algorithm
{
    public class Thing
    {
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
    }
}