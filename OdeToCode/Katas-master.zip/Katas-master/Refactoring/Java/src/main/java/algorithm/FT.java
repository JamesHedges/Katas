package algorithm;
public enum FT {
	One, Two
}
