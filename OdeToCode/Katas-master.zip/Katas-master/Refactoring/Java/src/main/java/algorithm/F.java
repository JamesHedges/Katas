package algorithm;
public class F {
	public Thing P1;
	public Thing P2;
	public long D;
}
