Katas
=====
C# and Java programs to practice your skills with. Inside each project is a README with the assingment. 
