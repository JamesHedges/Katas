namespace Algorithm
{
    public struct Measurement
    {
        public Measurement(int x, int y)
        {
            X = x;
            Y = y;
        }

        public int X;
        public int Y;
    }
}
