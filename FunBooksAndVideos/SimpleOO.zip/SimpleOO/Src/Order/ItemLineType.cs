﻿namespace Order
{
    public enum ItemLineType
    {
        Product,
        Membership
    }
}
