Simple Object Oriented FunBooksAndVideo Solution
================================================

This is my simple object oriented solution to the FunBooksAndVideo Kata

You may also find this on [GitHub](https://github.com/JamesHedges/Katas/tree/master/FunBooksAndVideos/SimpleOO)